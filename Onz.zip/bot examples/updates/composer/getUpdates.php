<?php

require_once '../../../vendor/autoload.php';

$bot_token = '773126593:AAFNHvx6Yb_hHHP2IJATbq0PLm55FHNyVcM';
$telegram = new Telegram($bot_token);

var_dump($telegram->getUpdates());
