-- phpMyAdmin SQL Dump
-- version 4.0.10.6
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 16 2018 г., 20:53
-- Версия сервера: 5.5.41-log
-- Версия PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `onzbot`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bot`
--

CREATE TABLE IF NOT EXISTS `bot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `money` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `user` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `channel` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `group` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `supergroup` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `admin` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `inmoney` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `outmoney` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `money_ref` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `bot`
--

INSERT INTO `bot` (`id`, `login`, `name`, `money`, `user`, `channel`, `group`, `supergroup`, `admin`, `inmoney`, `outmoney`, `money_ref`) VALUES
(1, 'uzpuluzbot', 'Ishlab top', '2500', '425', '17', '0', '0', '2', '700.6', '283.7', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `channel`
--

CREATE TABLE IF NOT EXISTS `channel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `sana` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `creator` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `creator_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `join` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `join_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `money` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `regcount` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `count` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `inuser` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `outuser` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `demo` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=28 ;

--
-- Дамп данных таблицы `channel`
--

INSERT INTO `channel` (`id`, `uid`, `login`, `title`, `link`, `sana`, `creator`, `creator_id`, `join`, `join_id`, `money`, `regcount`, `count`, `inuser`, `outuser`, `demo`) VALUES
(24, '', 'doda_prikol', '', '', '1521056605', '', '', 'Creator Admin', '489739082', '0', '0', '0', '0', '0', '1'),
(25, '', 'oox_uz', '', '', '1521076316', '', '', 'Xojiakbar ', '356697226', '0', '0', '0', '0', '0', '1');

-- --------------------------------------------------------

--
-- Структура таблицы `group`
--

CREATE TABLE IF NOT EXISTS `group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `sana` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `creator` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `creator_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `join` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `join_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `supergroup`
--

CREATE TABLE IF NOT EXISTS `supergroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `sana` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `creator` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `creator_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `join` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `join_id` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `text`
--

CREATE TABLE IF NOT EXISTS `text` (
  `id` int(10) unsigned NOT NULL,
  `payme` mediumtext NOT NULL,
  `rules` mediumtext NOT NULL,
  `chat` mediumtext NOT NULL,
  `qiwi` mediumtext NOT NULL,
  `webmoney` mediumtext NOT NULL,
  `advcash` mediumtext NOT NULL,
  `in` mediumtext NOT NULL,
  `in2` mediumtext NOT NULL,
  `in3` mediumtext NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `text`
--

INSERT INTO `text` (`id`, `payme`, `rules`, `chat`, `qiwi`, `webmoney`, `advcash`, `in`, `in2`, `in3`) VALUES
(1, '\nKarta: 8600 0000 0000 0000\n\nAdmin: @Xusan98\n\n', 'Salom 2', '@php_bot_kodlari', 'qiwi', 'Payeer', 'advcash', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `time` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `lan` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'uz',
  `ref` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `referal` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `admin` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `money` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `joinn` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `money_join` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `money_ref` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `outn` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `inmoney` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `outmoney` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `token` varchar(500) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `timezona` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=368 ;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `uid`, `login`, `name`, `time`, `lan`, `ref`, `referal`, `admin`, `money`, `joinn`, `money_join`, `money_ref`, `outn`, `inmoney`, `outmoney`, `token`, `timezona`) VALUES
(1, '420831885', 'Xusan98', 'Xusan', '1520279695', 'uz', '0', 'https://telegram.me/OnZBot?start=420831885', '0', '5', '1', '0.3', '0', '0', '0', '11', '0', '+5');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
