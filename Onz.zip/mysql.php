<?php

$bot_token= '773126593:AAFNHvx6Yb_hHHP2IJATbq0PLm55FHNyVcM';
$bot_name = 'uzpuluzbot';


$azobulish = '0.30';
$azotuplash = '0.50';
$reftuplash = '0.30';
$minimalka = '5';

$admin = '420831885';
$admin2 = '209852095';


$dbhost='localhost';
$dbname='baxt_uz';
$dbuser='baxt_uz';
$dbpass='parol5';


?>